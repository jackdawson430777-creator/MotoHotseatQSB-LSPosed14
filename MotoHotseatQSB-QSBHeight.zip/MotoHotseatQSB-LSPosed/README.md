# MotoHotseatQSB LSPosed — QSB height target fix (v1.4)

This project enables the Motorola Launcher hotseat search bar and exposes a 40–152 dp setting.

## Important correction

v1.3 hooked `Hotseat` and changed the whole dock's measured height. That moves the app icons and does **not** control the search bar height. v1.4 removes that hook and instead targets `com.android.launcher3.qsb.QsbContainerView` (including subclasses), the QSB search-bar container.

The hook changes the container's measured height, not the Hotseat/icon-row height. Depending on Moto's layout constraints and the embedded Google search widget implementation, the widget's own internal content may still retain its original height or be clipped. This is a source-level attempt and requires on-device verification; it is not a claim of confirmed compatibility.

## Build

Open this project in Android Studio with JDK 17 and Android SDK 35, then build `app-debug.apk`, or run the included GitHub Actions workflow.

## Install/test

1. Install the newly built APK over the previous module app.
2. Enable it in LSPosed and scope it to `com.motorola.launcher3`.
3. Open the app, choose the desired QSB height (start with 72 dp), and save.
4. Force-stop Motorola Launcher and reopen the home screen.
5. Check LSPosed logs for `applied QSB container height=...dp`.

If the log never appears, the actual Moto build may use a different QSB container class; send the relevant `MotoHotseatQSB` log lines so the target can be refined.
