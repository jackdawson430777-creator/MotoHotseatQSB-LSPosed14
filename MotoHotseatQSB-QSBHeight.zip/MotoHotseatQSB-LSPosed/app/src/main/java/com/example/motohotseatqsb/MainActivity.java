package com.example.motohotseatqsb;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/** Simple standalone settings screen; deliberately avoids deprecated shared preferences modes. */
public class MainActivity extends Activity {
    private static final int MIN_DP = 40;
    private static final int MAX_DP = 152;
    private TextView value;
    private SeekBar slider;
    private int dp = 72;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        try {
            buildScreen();
        } catch (Throwable t) {
            android.util.Log.e("MotoHotseatQSB", "Failed to build settings UI", t);
            TextView error = new TextView(this);
            error.setText("设置界面初始化失败：" + t.getClass().getSimpleName() + "\n" + String.valueOf(t.getMessage()));
            error.setTextSize(16);
            error.setPadding(24, 24, 24, 24);
            setContentView(error);
        }
    }

    private void buildScreen() {
        getWindow().setStatusBarColor(0xfff5f5f5);
        getWindow().setNavigationBarColor(0xfff5f5f5);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPx(22);
        root.setPadding(pad, dpToPx(24), pad, dpToPx(28));
        root.setBackgroundColor(0xfffafafa);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Moto Dock 高度控制");
        title.setTextSize(24);
        title.setTextColor(0xff171717);
        root.addView(title, matchWrap());

        TextView desc = new TextView(this);
        desc.setText("控制 Motorola Launcher 底部 Dock / 搜索栏区域的目标高度。\n\n作用域：com.motorola.launcher3\n修改后需要重新启动桌面进程。\n");
        desc.setTextSize(14);
        desc.setTextColor(0xff555555);
        desc.setPadding(0, dpToPx(12), 0, dpToPx(12));
        root.addView(desc, matchWrap());

        value = new TextView(this);
        value.setTextSize(20);
        value.setTextColor(0xff202020);
        root.addView(value, matchWrap());

        slider = new SeekBar(this);
        slider.setMax(MAX_DP - MIN_DP);
        root.addView(slider, matchWrap());

        TextView range = new TextView(this);
        range.setText("40 dp                                      152 dp");
        range.setTextSize(12);
        range.setTextColor(0xff666666);
        root.addView(range, matchWrap());

        dp = getSharedPreferences("MotoDockPrefs", MODE_PRIVATE).getInt("dock_height_dp", 72);
        dp = Math.max(MIN_DP, Math.min(MAX_DP, dp));
        slider.setProgress(dp - MIN_DP);
        updateLabel();
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                dp = MIN_DP + progress;
                updateLabel();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { save(false); }
        });

        Button save = new Button(this);
        save.setText("保存高度");
        root.addView(save, matchWrap());
        save.setOnClickListener(v -> save(true));

        Button help = new Button(this);
        help.setText("查看启用与排查说明");
        root.addView(help, matchWrap());
        help.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("使用说明")
                .setMessage("1. 在 LSPosed 中启用模块。\n2. 作用域勾选 com.motorola.launcher3。\n3. 拖动滑块设置高度并点击保存。\n4. 强制停止 Motorola Launcher 后回到桌面。\n\n如果高度不变，请在 LSPosed 日志中搜索 MotoHotseatQSB，并确认出现 applied Hotseat measured height。不同版本的启动器可能使用不同 Hotseat 类或布局约束。")
                .setPositiveButton("知道了", null).show());

        TextView note = new TextView(this);
        note.setText("提示：40–152 dp 是目标高度范围。若出现图标挤压、搜索栏裁切或布局重叠，请逐步调整高度。此模块不修改系统分区。");
        note.setTextColor(0xff777777);
        note.setTextSize(12);
        note.setPadding(0, dpToPx(14), 0, 0);
        root.addView(note, matchWrap());
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dpToPx(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void save(boolean showToast) {
        boolean ok = getSharedPreferences("MotoDockPrefs", MODE_PRIVATE).edit()
                .putInt("dock_height_dp", dp).commit();
        if (showToast) Toast.makeText(this, ok ? ("已保存：" + dp + " dp。请重启桌面进程") : "保存失败，请重试", Toast.LENGTH_LONG).show();
    }

    private void updateLabel() {
        if (value != null) value.setText("Dock 目标高度：" + dp + " dp");
    }
}
