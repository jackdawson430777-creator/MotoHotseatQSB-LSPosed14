package com.example.motohotseatqsb;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.content.UriMatcher;

/** Read-only bridge so the launcher process can read the height from the UI app. */
public final class DockPrefsProvider extends ContentProvider {
    public static final String AUTHORITY = "com.example.motohotseatqsb.prefs";
    private static final int HEIGHT = 1;
    private static final UriMatcher MATCHER = new UriMatcher(UriMatcher.NO_MATCH);
    static { MATCHER.addURI(AUTHORITY, "dock_height", HEIGHT); }

    @Override public boolean onCreate() { return true; }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        if (MATCHER.match(uri) != HEIGHT || getContext() == null) return null;
        int dp = getContext().getSharedPreferences("MotoDockPrefs", 0).getInt("dock_height_dp", 72);
        MatrixCursor cursor = new MatrixCursor(new String[]{"height_dp"});
        cursor.addRow(new Object[]{dp});
        return cursor;
    }
    @Override public String getType(Uri uri) { return "vnd.android.cursor.item/vnd.com.example.motohotseatqsb.height"; }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException("read-only"); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read-only"); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException("read-only"); }
}
