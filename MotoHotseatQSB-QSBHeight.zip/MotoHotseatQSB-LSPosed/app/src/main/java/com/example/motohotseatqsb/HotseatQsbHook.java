package com.example.motohotseatqsb;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.TypedValue;
import android.view.View;

import de.robv.android.xposed.IXposedHookInitPackageResources;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_InitPackageResources;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import android.content.res.XResources;

/**
 * Enables Moto Launcher's QSB and adjusts the QSB container itself.
 * Important: do not change Hotseat's measured height; that moves the dock icons
 * and is not the search-bar height control the user requested.
 */
public final class HotseatQsbHook implements IXposedHookInitPackageResources, IXposedHookLoadPackage {
    private static final String TARGET = "com.motorola.launcher3";
    private static final String QSB_CONTAINER = "com.android.launcher3.qsb.QsbContainerView";
    private static final Uri PREF_URI = Uri.parse("content://" + DockPrefsProvider.AUTHORITY + "/dock_height");

    @Override
    public void handleInitPackageResources(XC_InitPackageResources.InitPackageResourcesParam p) {
        if (!TARGET.equals(p.packageName)) return;
        replaceBool(p.res, "config_enable_hotseat_qsb");
        replaceBool(p.res, "config_hotseat_qsb_default_value");
        XposedBridge.log("MotoHotseatQSB: QSB bool resource hook loaded");
    }

    private void replaceBool(XResources r, String name) {
        try {
            if (r.getIdentifier(name, "bool", TARGET) != 0) {
                r.setReplacement(TARGET, "bool", name, true);
                XposedBridge.log("MotoHotseatQSB: replaced bool/" + name + "=true");
            } else {
                XposedBridge.log("MotoHotseatQSB: bool resource not found: " + name);
            }
        } catch (Throwable t) {
            XposedBridge.log("MotoHotseatQSB: bool hook failed " + name + ": " + t);
        }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam p) {
        if (!TARGET.equals(p.packageName)) return;
        XposedBridge.log("MotoHotseatQSB: loaded into Motorola Launcher");
        try {
            XposedHelpers.findAndHookMethod(View.class, "measure", int.class, int.class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        Object obj = param.thisObject;
                        if (!isQsbContainer(obj.getClass())) return;
                        try {
                            View view = (View) obj;
                            int dp = readHeightDp(view.getContext());
                            int px = Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                                dp, view.getResources().getDisplayMetrics()));
                            int width = view.getMeasuredWidth();
                            XposedHelpers.callMethod(view, "setMeasuredDimension", width, px);
                            XposedBridge.log("MotoHotseatQSB: applied QSB container height=" + dp + "dp (" + px + "px)");
                        } catch (Throwable t) {
                            XposedBridge.log("MotoHotseatQSB: failed to apply QSB container height: " + t);
                        }
                    }
                });
            XposedBridge.log("MotoHotseatQSB: installed QSB-container measured-height hook for " + QSB_CONTAINER);
        } catch (Throwable t) {
            XposedBridge.log("MotoHotseatQSB: could not install QSB-container height hook: " + t);
        }
    }

    private boolean isQsbContainer(Class<?> c) {
        while (c != null) {
            String name = c.getName();
            if (name.equals(QSB_CONTAINER) || name.endsWith(".QsbContainerView")) return true;
            c = c.getSuperclass();
        }
        return false;
    }

    private int readHeightDp(Context context) {
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(PREF_URI, new String[]{"height_dp"}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) return Math.max(40, Math.min(152, cursor.getInt(0)));
        } catch (Throwable t) {
            XposedBridge.log("MotoHotseatQSB: unable to read QSB height preference: " + t);
        } finally {
            if (cursor != null) cursor.close();
        }
        return 72;
    }
}
